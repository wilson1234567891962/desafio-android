package principal.concrete.concrete;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;
import com.google.gson.Gson;

import java.util.ArrayList;


public class PullRequestActivity extends Activity {

    private ListView listView;
    private AdaptadorPull adaptadorPull;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pull_request);
        processDto();

    }

    private void processDto(){
        Gson gson=new Gson();
        try {
            String  json = (String)getIntent().getExtras().getSerializable("requestPull");
            MappingDtoPull[] jsonPull = (MappingDtoPull[]) gson.fromJson(json, MappingDtoPull[].class);
            getArrayList(jsonPull);
        }catch(Exception e){
            Log.d("PullReques processDto", e.toString());
        }
    }

    private void getArrayList(MappingDtoPull[] jsonPull) {

        ArrayList<EntityCache> listItems=new ArrayList<>();
        try {
            if(jsonPull==null || jsonPull.length<=0){
                Toast.makeText(getApplicationContext(),"Para ese reposotorio no tenemos Vounches",Toast.LENGTH_LONG).show();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            } else {
                MappingDtoPull mappingDtoPull;
                listView=(ListView)  findViewById(R.id.pull);
                for(int k=0;k<jsonPull.length;k++){
                    mappingDtoPull=jsonPull[k];
                    listItems.add(new EntityCache(mappingDtoPull.getUser().getAvatar_url(),mappingDtoPull.getHead().getUser().getLogin(),mappingDtoPull.getTitle(),mappingDtoPull.getUser().getLogin(),1,1,mappingDtoPull.getHead().getRepo().getHtml_url()," " ));
                }
                adaptadorPull=new AdaptadorPull(this,listItems);
                listView.setAdapter(adaptadorPull);
            }

        } catch(Exception e){
            Log.d("PullReques getArrayList", e.toString());
        }

    }

    //Methos get and set
    public ListView getListView() {
        return listView;
    }

    public void setListView(ListView listView) {
        this.listView = listView;
    }

    public AdaptadorPull getAdaptadorPull() {
        return adaptadorPull;
    }

    public void setAdaptadorPull(AdaptadorPull adaptadorPull) {
        this.adaptadorPull = adaptadorPull;
    }



}
