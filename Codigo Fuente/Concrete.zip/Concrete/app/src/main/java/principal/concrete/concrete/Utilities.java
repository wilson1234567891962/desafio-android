package principal.concrete.concrete;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import com.google.gson.Gson;

import java.util.concurrent.ExecutionException;

public class Utilities {

    private Context context;
    private ConnectivityManager connManager;
    public Utilities(Context ctx) {
        this.context = ctx;
    }

    public String getJson(String url) {
        String jsonFormat = null;
         try{
             Post post=new Post();
             jsonFormat=post.execute(url).get();
         }catch(ExecutionException | InterruptedException e){
             Log.d("Json getJson", e.toString());
         }
        return jsonFormat;

    }


    public Object convertDto(int indicate, String json){
        Object object = null;
        Gson gson=new Gson();
        switch (indicate){
            case 1:
                object=(MappingDto) gson.fromJson(json, MappingDto.class);
                break;
            case 2:
                object=(MappingDtoPull[]) gson.fromJson(json, MappingDtoPull[].class);
                break;
        }
        return object;
    }




    public  boolean isConnectedWifi() {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnectedOrConnecting();
    }
}
