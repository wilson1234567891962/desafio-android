package principal.concrete.concrete;

import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.content.Context;
import android.widget.ImageView;
import java.util.ArrayList;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.widget.Toast;

public class Adaptador extends BaseAdapter {

    private Context context;
    private ArrayList<EntityCache> listItems;

    public Adaptador(Context context, ArrayList<EntityCache> listItems){
        this.context=context;
        this.listItems=listItems;

    }



    @Override
    public int getCount() {
        return listItems.size();
    }

    @Override
    public Object getItem(int i) {
        return listItems.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, final ViewGroup viewGroup) {

        try{
            if (view == null) {
                LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
                view = inflater.inflate(R.layout.item, viewGroup, false);
            }
            final EntityCache item=(EntityCache) getItem(i);
            view= LayoutInflater.from(context).inflate(R.layout.item,null);
            ImageView imgPhoto=(ImageView) view.findViewById(R.id.photo);
            TextView tv=(TextView) view.findViewById(R.id.tittle);
            TextView contenido=(TextView) view.findViewById(R.id.description);

            TextView nombre=(TextView) view.findViewById(R.id.name);
            TextView points=(TextView) view.findViewById(R.id.points);

            new DownloadImageTask(imgPhoto).execute(item.getRutaImage());
            tv.setText("Title: "+item.getTittle());
            contenido.setText("Description: "+item.getContent());
            nombre.setText("Author's name: "+item.getNameAuthor());
            points.setText("Forks: "+item.getForks()+"   Starts: "+item.getStarts());

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        Post post=new Post();
                        Intent intent = new Intent(context, PullRequestActivity.class);
                        intent.putExtra("requestPull",post.execute("https://api.github.com/repos/"+item.getFullName()+"/pulls").get());
                        context.startActivity(intent);
                    }catch(Exception e){
                        Toast.makeText(viewGroup.getContext(), e.toString(), Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }catch(Exception e){
            Log.d("Registry gitMappingView", e.toString());
        }
        return view;
    }


}
