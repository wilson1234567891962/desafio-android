package principal.concrete.concrete;

public class MappingHeadPull {
    private String label;
    private String sha;
    private MappingUserPull user;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getSha() {
        return sha;
    }

    public void setSha(String sha) {
        this.sha = sha;
    }

    public MappingUserPull getUser() {
        return user;
    }

    public void setUser(MappingUserPull user) {
        this.user = user;
    }

    public MappingRepoPull getRepo() {
        return repo;
    }

    public void setRepo(MappingRepoPull repo) {
        this.repo = repo;
    }

    private MappingRepoPull repo;

}
