package principal.concrete.concrete;

import android.graphics.Bitmap;
import android.os.AsyncTask;

public class EntityCache {

    private String rutaImage;
    private String tittle;
    private String content;
    private String nameAuthor;
    private long starts;
    private long forks;
    private String urlRepository;
    private String fullName;


    public EntityCache(String imbPhot, String tittle, String content, String nameAuthor, long starts, long forks, String urlRepository, String fullName){
        this.rutaImage=imbPhot;
        this.tittle=tittle;
        this.content=content;
        this.nameAuthor=nameAuthor;
        this.starts=starts;
        this.forks=forks;
        this.urlRepository=urlRepository;
        this.fullName=fullName;
    }

    public String getRutaImage() {
        return rutaImage;
    }

    public void setRutaImage(String rutaImage) {
        this.rutaImage = rutaImage;
    }

    public String getTittle() {
        return tittle;
    }

    public void setTittle(String tittle) {
        this.tittle = tittle;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getNameAuthor() {
        return nameAuthor;
    }

    public void setNameAuthor(String nameAuthor) {
        this.nameAuthor = nameAuthor;
    }

    public long getStarts() {
        return starts;
    }

    public void setStarts(long starts) {
        this.starts = starts;
    }

    public long getForks() {
        return forks;
    }

    public void setForks(long forks) {
        this.forks = forks;
    }

    public String getUrlRepository() {
        return urlRepository;
    }

    public void setUrlRepository(String urlRepository) {
        this.urlRepository = urlRepository;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }



}
