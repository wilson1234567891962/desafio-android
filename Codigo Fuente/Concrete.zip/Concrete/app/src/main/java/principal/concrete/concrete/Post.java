package principal.concrete.concrete;

import android.os.AsyncTask;
import android.util.Log;

import java.io.IOException;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Post extends AsyncTask<String, Void, String> {

    private InputStreamReader inputStreamReader;
    private BufferedReader bufferedReader;

    @Override
    protected String doInBackground(String... params){

        try {
            URL obj = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("User-Agent", " ");
            con.connect();
            inputStreamReader=new InputStreamReader(con.getInputStream());
            bufferedReader = new BufferedReader(inputStreamReader);
            return bufferedReader.readLine();
        }catch(Exception e){
            Log.d("Url  doInBackground", e.toString());
            return null;
        } finally {
            try {
                closeConnection();
            } catch(Exception e){

            }
        }

    }

    private void closeConnection() {
        try {
            if(bufferedReader!=null){
                bufferedReader.close();
            }

            if(inputStreamReader!=null){
                inputStreamReader.close();
            }
        }catch(IOException ex){
            Log.d("Url disconnect", ex.toString());
        }
    }

    @Override
    protected void onPostExecute(String result){

        super.onPostExecute(result);
    }
}