package principal.concrete.concrete;
import android.util.Log;
import android.widget.Toast;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView ListView;
    private Adaptador adaptador;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        consultarUrl();
    }


    private void consultarUrl() {

        try {
            Utilities utilities=new Utilities(this);
            if(utilities.isConnectedWifi()){
                MappingDto jsonGit = (MappingDto) utilities.convertDto(1,   utilities.getJson("https://api.github.com/search/repositories?q=language:Java&sort=stars&page=1"));
                getArrayList(jsonGit);

            } else {
                Toast.makeText(getApplicationContext(),"Por favor conectese a la red es necesario",Toast.LENGTH_LONG).show();
            }


        }catch(Exception e){
            Log.d("Registry gitRepository", e.toString());
        }
    }


    private void getArrayList(MappingDto jsonGit) {

        ArrayList<EntityCache> listItems=new ArrayList<>();
        try {
            ListView=(ListView)  findViewById(R.id.gitRepository);
            for(int k=0;k<jsonGit.getItems().size();k++){
                listItems.add(new EntityCache(jsonGit.getItems().get(k).getOwner().getAvatar_url(),jsonGit.getItems().get(k).getName(),jsonGit.getItems().get(k).getDescription(),jsonGit.getItems().get(k).getFull_name(),jsonGit.getItems().get(k).getForks(),jsonGit.getItems().get(k).getStargazers_count(),jsonGit.getItems().get(k).getUrl(),jsonGit.getItems().get(k).getFull_name()));
            }
            adaptador=new Adaptador(this,listItems);
            ListView.setAdapter(adaptador);
        } catch(Exception e){
            Log.d("Registry gitMappingRepo", e.toString());
        }

    }

    //Methods get and set
    public android.widget.ListView getListView() {
        return ListView;
    }

    public void setListView(android.widget.ListView listView) {
        ListView = listView;
    }

    public Adaptador getAdaptador() {
        return adaptador;
    }

    public void setAdaptador(Adaptador adaptador) {
        this.adaptador = adaptador;
    }


}
