package principal.concrete.concrete;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class AdaptadorPull extends BaseAdapter {

    private Context context;
    private ArrayList<EntityCache> listItems;

    public AdaptadorPull(Context context, ArrayList<EntityCache> listItems){
        this.context=context;
        this.listItems=listItems;

    }

    @Override
    public int getCount() {
        return listItems.size();
    }

    @Override
    public Object getItem(int i) {
        return listItems.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, final ViewGroup viewGroup) {
        try {
            if (view == null) {
                LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
                view = inflater.inflate(R.layout.pull, viewGroup, false);
            }

            final EntityCache item=(EntityCache) getItem(i);
            view= LayoutInflater.from(context).inflate(R.layout.pull,null);


            ImageView pullPhoto=(ImageView) view.findViewById(R.id.pullPhoto);
            TextView namePull=(TextView) view.findViewById(R.id.namePull);
            TextView tittlePull=(TextView) view.findViewById(R.id.tittlePull);
            TextView pointsPull=(TextView) view.findViewById(R.id.pointsPull);



            new DownloadImageTask(pullPhoto).execute(item.getRutaImage());
            namePull.setText("Description: "+item.getContent());
            tittlePull.setText("Title: "+item.getTittle());
            pointsPull.setText(item.getForks()+" / "+item.getStarts());

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(item.getUrlRepository()));
                        context.startActivity(browserIntent);
                    }catch(Exception e){
                        Log.d("Registry listenerPullRe", e.toString());
                    }

                }
            });
        }catch(Exception e){
            Log.d("Event listenerPullRe", e.toString());
        }
        return view;
    }


}
