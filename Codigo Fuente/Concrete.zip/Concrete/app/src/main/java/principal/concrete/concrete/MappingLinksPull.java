package principal.concrete.concrete;

public class MappingLinksPull {

    private MappingSelfPull self ;
    private MappingHtmlPull html ;
    private MappingIssuePull issue ;
    private MappingCommentsPull comments ;
    private MappingReviewCommentsPull review_comments ;
    private MappingReviewCommentPull review_comment ;
    private MappingCommitsPull commits ;

    public MappingSelfPull getSelf() {
        return self;
    }

    public void setSelf(MappingSelfPull self) {
        this.self = self;
    }

    public MappingHtmlPull getHtml() {
        return html;
    }

    public void setHtml(MappingHtmlPull html) {
        this.html = html;
    }

    public MappingIssuePull getIssue() {
        return issue;
    }

    public void setIssue(MappingIssuePull issue) {
        this.issue = issue;
    }

    public MappingCommentsPull getComments() {
        return comments;
    }

    public void setComments(MappingCommentsPull comments) {
        this.comments = comments;
    }

    public MappingReviewCommentsPull getReview_comments() {
        return review_comments;
    }

    public void setReview_comments(MappingReviewCommentsPull review_comments) {
        this.review_comments = review_comments;
    }

    public MappingReviewCommentPull getReview_comment() {
        return review_comment;
    }

    public void setReview_comment(MappingReviewCommentPull review_comment) {
        this.review_comment = review_comment;
    }

    public MappingCommitsPull getCommits() {
        return commits;
    }

    public void setCommits(MappingCommitsPull commits) {
        this.commits = commits;
    }

    public MappingStatusesPull getStatuses() {
        return statuses;
    }

    public void setStatuses(MappingStatusesPull statuses) {
        this.statuses = statuses;
    }

    private MappingStatusesPull statuses ;


}
