package principal.concrete.concrete;
import java.util.Date;

public class MappingMilestonePull {

    private String url ;
    private String html_url ;
    private String labels_url ;
    private long id ;
    private String node_id ;
    private long number ;
    private String title ;
    private String description ;
    private MappingCreatorPull creator ;
    private long open_issues ;
    private long closed_issues ;
    private String state ;
    private Date created_at ;
    private Date updated_at ;
    private Object due_on ;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getHtml_url() {
        return html_url;
    }

    public void setHtml_url(String html_url) {
        this.html_url = html_url;
    }

    public String getLabels_url() {
        return labels_url;
    }

    public void setLabels_url(String labels_url) {
        this.labels_url = labels_url;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNode_id() {
        return node_id;
    }

    public void setNode_id(String node_id) {
        this.node_id = node_id;
    }

    public long getNumber() {
        return number;
    }

    public void setNumber(long number) {
        this.number = number;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public MappingCreatorPull getCreator() {
        return creator;
    }

    public void setCreator(MappingCreatorPull creator) {
        this.creator = creator;
    }

    public long getOpen_issues() {
        return open_issues;
    }

    public void setOpen_issues(long open_issues) {
        this.open_issues = open_issues;
    }

    public long getClosed_issues() {
        return closed_issues;
    }

    public void setClosed_issues(long closed_issues) {
        this.closed_issues = closed_issues;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }

    public Date getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(Date updated_at) {
        this.updated_at = updated_at;
    }

    public Object getDue_on() {
        return due_on;
    }

    public void setDue_on(Object due_on) {
        this.due_on = due_on;
    }

    public Object getClosed_at() {
        return closed_at;
    }

    public void setClosed_at(Object closed_at) {
        this.closed_at = closed_at;
    }

    private Object closed_at;


}
