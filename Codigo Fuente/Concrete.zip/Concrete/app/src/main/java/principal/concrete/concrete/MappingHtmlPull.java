package principal.concrete.concrete;

public class MappingHtmlPull {
    private String href;

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }
}
